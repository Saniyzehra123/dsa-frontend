import React from 'react'
import './Navbar.css'; 

export default function Blog() {
  return (
    <div>
       <div className="containter-fluid ">
      <div className="row">
        <div className="col-md-12 u1"></div>  
     
        <div className="col-md-12 u2"> <h1 className='text-6xl'>Blog</h1></div>
      
      </div>

     </div>

    </div>
  )
}
