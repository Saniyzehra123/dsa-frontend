import React from 'react'

const Newarrivals = () => {
  return (
    <div>
      Newarrivals
      
      </div>
  )
}

export default Newarrivals