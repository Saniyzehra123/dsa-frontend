 // src/redux/contact/contactActionTypes.js
export const CONTACT_FORM_REQUEST = 'CONTACT_FORM_REQUEST';
export const CONTACT_FORM_SUCCESS = 'CONTACT_FORM_SUCCESS';
export const CONTACT_FORM_FAILURE= 'CONTACT_FORM_FAIL';
